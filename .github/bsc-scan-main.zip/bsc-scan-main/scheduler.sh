/usr/bin/python3 /workspace/ronen.py
sleep 10
/usr/bin/python3 /workspace/ronen.py
sleep 10
/usr/bin/python3 /workspace/ronen.py
